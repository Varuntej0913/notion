function wikiBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fcarousel%2Fassistant%2FWiki-V2.png&w=3840&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "#bbbdbc";
    document.getElementById("docsELe").style.backgroundColor = "white";
    document.getElementById("projectEle").style.backgroundColor = "white";
    document.getElementById("aiEle").style.backgroundColor = "white";
    document.getElementById("calenderEle").style.backgroundColor = "white";
    document.getElementById("sitesEle").style.backgroundColor = "white";
}

function docsBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fcarousel%2Fassistant%2FDocs-V2.png&w=1920&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "white";
    document.getElementById("docsELe").style.backgroundColor = "#bbbdbc";
    document.getElementById("projectEle").style.backgroundColor = "white";
    document.getElementById("aiEle").style.backgroundColor = "white";
    document.getElementById("calenderEle").style.backgroundColor = "white";
    document.getElementById("sitesEle").style.backgroundColor = "white";
}

function projectsBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fcarousel%2Fassistant%2FProjects-V2.png&w=3840&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "white";
    document.getElementById("docsELe").style.backgroundColor = "white";
    document.getElementById("projectEle").style.backgroundColor = "#bbbdbc";
    document.getElementById("aiEle").style.backgroundColor = "white";
    document.getElementById("calenderEle").style.backgroundColor = "white";
    document.getElementById("sitesEle").style.backgroundColor = "white";
}

function aiBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fcarousel%2Fassistant%2FAI-V2.png&w=1920&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "white";
    document.getElementById("docsELe").style.backgroundColor = "white";
    document.getElementById("projectEle").style.backgroundColor = "white";
    document.getElementById("aiEle").style.backgroundColor = "#bbbdbc";
    document.getElementById("calenderEle").style.backgroundColor = "white";
    document.getElementById("sitesEle").style.backgroundColor = "white";
}

function calenderBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fdownload%2Fnotion-calendar.png&w=1920&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "white";
    document.getElementById("docsELe").style.backgroundColor = "white";
    document.getElementById("projectEle").style.backgroundColor = "white";
    document.getElementById("aiEle").style.backgroundColor = "white";
    document.getElementById("calenderEle").style.backgroundColor = "#bbbdbc";
    document.getElementById("sitesEle").style.backgroundColor = "white";
}

function sitesBtn() {
    document.getElementById("imgEle").src = "https://www.notion.com/_next/image?url=%2Ffront-static%2Fpages%2Fproduct%2Fsuper-duper%2Fcarousel%2Fsites.png&w=3840&q=75";
    document.getElementById("wikisELe").style.backgroundColor = "white";
    document.getElementById("docsELe").style.backgroundColor = "white";
    document.getElementById("projectEle").style.backgroundColor = "white";
    document.getElementById("aiEle").style.backgroundColor = "white";
    document.getElementById("calenderEle").style.backgroundColor = "white";
    document.getElementById("sitesEle").style.backgroundColor = "#bbbdbc";
}